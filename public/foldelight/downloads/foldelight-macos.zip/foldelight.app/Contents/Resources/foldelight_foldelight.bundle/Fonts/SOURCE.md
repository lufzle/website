# IBM Plex Sans

Unmodified Regular, Medium, and SemiBold TrueType fonts from IBM's official
[Plex repository](https://github.com/IBM/plex/tree/master/packages/plex-sans/fonts/complete/ttf).
Downloaded on 2026-09-10. The included OFL.txt is the repository's
[SIL Open Font License 1.1](https://github.com/IBM/plex/blob/master/LICENSE.txt).

PostScript names verified directly from the downloaded font name tables:

- Regular: `IBMPlexSans`
- Medium: `IBMPlexSans-Medm`
- SemiBold: `IBMPlexSans-SmBld`
